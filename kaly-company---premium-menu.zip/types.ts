
export interface PriceOption {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  titre: string;
  category: string;
  image: string;
  prix: PriceOption[];
  description?: string;
}

export interface Order {
  id: string;
  date: string;
  items: string[];
  total: string;
}

export interface UserProfile {
  id: string;
  username: string;
  photo: string;
  favorites: string[];
  orderHistory: Order[];
  ordersCount: number;
}

export type AppView = 'home' | 'categories' | 'cart' | 'profile';
export type Language = 'fr' | 'es';
