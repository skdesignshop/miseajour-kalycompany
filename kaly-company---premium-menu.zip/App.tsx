
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Search, 
  ShoppingBag, 
  Home, 
  Grid, 
  Globe, 
  User as UserIcon, 
  Heart, 
  ChevronRight,
  X,
  Plus,
  Minus,
  MessageCircle,
  Clock,
  Ticket
} from 'lucide-react';
import { PRODUITS, CATEGORIES, TRANSLATIONS } from './constants';
import { Product, AppView, Language, UserProfile } from './types';

// Components
const ProductCard: React.FC<{ 
  product: Product; 
  onView: (p: Product) => void;
  onLike: (id: string) => void;
  isLiked: boolean;
}> = ({ product, onView, onLike, isLiked }) => {
  return (
    <div className="card-3d glass rounded-3xl p-4 flex flex-col items-center group relative overflow-hidden">
      <div className="absolute top-3 right-3 z-10">
        <button 
          onClick={(e) => { e.stopPropagation(); onLike(product.id); }}
          className={`p-2 rounded-full transition-all ${isLiked ? 'bg-red-500 text-white' : 'bg-white/10 text-white hover:bg-white/20'}`}
        >
          <Heart size={18} fill={isLiked ? "currentColor" : "none"} />
        </button>
      </div>
      <div className="w-full aspect-square rounded-2xl overflow-hidden mb-4 relative">
        <img 
          src={product.image} 
          alt={product.titre} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-4">
           <button 
             onClick={() => onView(product)}
             className="px-4 py-2 bg-blue-500 rounded-full text-sm font-bold shadow-lg shadow-blue-500/50 transform translate-y-4 group-hover:translate-y-0 transition-transform"
           >
             Détails
           </button>
        </div>
      </div>
      <h3 className="text-white font-bold text-center text-lg mb-1 truncate w-full">{product.titre}</h3>
      <p className="text-blue-400 text-xs font-semibold uppercase tracking-wider">{product.category}</p>
    </div>
  );
};

const Modal: React.FC<{ product: Product; isOpen: boolean; onClose: () => void; onAddToCart: (p: Product, option: string) => void }> = ({ product, isOpen, onClose, onAddToCart }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose} />
      <div className="relative glass w-full max-w-md rounded-[2.5rem] overflow-hidden animate-in fade-in zoom-in duration-300">
        <button onClick={onClose} className="absolute top-6 right-6 z-10 bg-white/10 p-2 rounded-full text-white"><X size={20}/></button>
        <img src={product.image} className="w-full h-64 object-cover" />
        <div className="p-8">
          <h2 className="text-2xl font-bold text-white mb-2">{product.titre}</h2>
          <p className="text-gray-400 text-sm mb-6">{product.description || "Une sélection premium de KALY COMPANY."}</p>
          <div className="space-y-3">
            {product.prix.map((p, idx) => (
              <div key={idx} className="flex items-center justify-between p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-blue-500 transition-colors group">
                <span className="text-white font-bold">{p.label}</span>
                <div className="flex items-center gap-4">
                  <span className="text-blue-400 font-bold">{p.value}</span>
                  <button 
                    onClick={() => onAddToCart(product, `${p.label} - ${p.value}`)}
                    className="p-2 bg-blue-500 rounded-xl text-white opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Plus size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const ProfileDrawer: React.FC<{ 
  user: UserProfile; 
  isOpen: boolean; 
  onClose: () => void; 
  lang: Language; 
  onToggleLang: () => void;
}> = ({ user, isOpen, onClose, lang, onToggleLang }) => {
  const t = TRANSLATIONS[lang];
  return (
    <div className={`fixed inset-y-0 left-0 z-[60] w-full max-w-sm bg-[#0f0f0f] shadow-2xl transition-transform duration-500 ease-out border-r border-white/10 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="p-8 h-full flex flex-col">
        <div className="flex items-center justify-between mb-10">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-3xl bg-blue-500 flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-blue-500/30 overflow-hidden">
               <img src={user.photo} alt="Avatar" className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-white text-xl font-bold">@{user.username}</h2>
              <p className="text-blue-400 text-sm font-semibold">{user.ordersCount} Commandes</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-gray-400"><X /></button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-8 scroll-hide">
          <section>
            <h3 className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
              <Heart size={14} /> {t.favorites}
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {user.favorites.length > 0 ? user.favorites.map(id => {
                const p = PRODUITS.find(item => item.id === id);
                return p ? (
                  <div key={id} className="p-2 glass rounded-2xl flex items-center gap-2">
                    <img src={p.image} className="w-8 h-8 rounded-lg object-cover" />
                    <span className="text-white text-[10px] font-bold truncate">{p.titre}</span>
                  </div>
                ) : null;
              }) : <p className="text-white/20 text-xs italic">Aucun favori</p>}
            </div>
          </section>

          <section>
            <h3 className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
              <Clock size={14} /> {t.history}
            </h3>
            <div className="space-y-3">
              {user.orderHistory.map(order => (
                <div key={order.id} className="p-4 glass rounded-2xl flex justify-between items-center">
                  <div>
                    <p className="text-white text-sm font-bold">Order #{order.id}</p>
                    <p className="text-gray-500 text-[10px]">{order.date}</p>
                  </div>
                  <span className="text-blue-400 font-bold">{order.total}</span>
                </div>
              ))}
            </div>
          </section>

          <section>
             <h3 className="text-gray-500 text-xs font-bold uppercase tracking-widest mb-4 flex items-center gap-2">
              <Ticket size={14} /> {t.coupons}
            </h3>
            <div className="p-4 rounded-3xl bg-gradient-to-br from-blue-600 to-indigo-700 text-white shadow-xl relative overflow-hidden">
               <div className="absolute -right-4 -top-4 w-16 h-16 bg-white/10 rounded-full blur-xl" />
               <p className="text-xs opacity-80 mb-1">{t.orderLimit}</p>
               <div className="h-2 w-full bg-black/20 rounded-full overflow-hidden mb-2">
                  <div className="h-full bg-white transition-all duration-1000" style={{ width: `${(user.ordersCount % 10) * 10}%` }} />
               </div>
               <p className="text-[10px] font-bold text-right">{user.ordersCount % 10}/10</p>
            </div>
          </section>
        </div>

        <div className="mt-8 pt-6 border-t border-white/10">
          <button 
            onClick={onToggleLang}
            className="w-full p-4 glass rounded-2xl flex items-center justify-between text-white group"
          >
            <div className="flex items-center gap-3">
              <Globe className="text-blue-400 group-hover:rotate-12 transition-transform" />
              <span className="font-bold">{lang.toUpperCase()} - {t.lang}</span>
            </div>
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [view, setView] = useState<AppView>('home');
  const [lang, setLang] = useState<Language>('fr');
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('Tous');
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<{product: Product, option: string}[]>([]);
  const [user, setUser] = useState<UserProfile>({
    id: '123',
    username: 'KalyUser',
    photo: 'https://picsum.photos/seed/user/200/200',
    favorites: [],
    orderHistory: [
      { id: '1001', date: '12 Mars 2024', total: '45€', items: ['Amnesia'] },
      { id: '1002', date: '20 Mars 2024', total: '70€', items: ['No Farm 90u'] }
    ],
    ordersCount: 2
  });

  const t = TRANSLATIONS[lang];

  const filteredProducts = useMemo(() => {
    return PRODUITS.filter(p => {
      const matchesSearch = p.titre.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = activeCategory === 'Tous' || p.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [search, activeCategory]);

  const toggleLike = (id: string) => {
    setUser(prev => ({
      ...prev,
      favorites: prev.favorites.includes(id) 
        ? prev.favorites.filter(fid => fid !== id)
        : [...prev.favorites, id]
    }));
  };

  const addToCart = (product: Product, option: string) => {
    setCart(prev => [...prev, { product, option }]);
    setSelectedProduct(null);
  };

  const removeFromCart = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const handleCheckout = () => {
    const contact = "kalicompany";
    const itemsText = cart.map(item => `- ${item.product.titre} (${item.option})`).join('\n');
    const msg = encodeURIComponent(`Bonjour Kaly Company, je souhaite commander :\n${itemsText}`);
    window.open(`https://t.me/${contact}?text=${msg}`, "_blank");
  };

  return (
    <div className="min-h-screen pb-24 text-white">
      {/* Background Decor */}
      <div className="fixed inset-0 pointer-events-none -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-indigo-600/20 rounded-full blur-[120px]" />
      </div>

      {/* Top Header */}
      <header className="p-6 flex items-center justify-between sticky top-0 z-40 bg-[#0a0a0a]/80 backdrop-blur-lg">
        <button 
          onClick={() => setIsProfileOpen(true)}
          className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center hover:scale-105 transition-transform"
        >
          <UserIcon size={24} className="text-blue-400" />
        </button>
        <div className="flex flex-col items-center">
          <img src="https://i.postimg.cc/XYgknHN2/IMG-2496.png" alt="Logo" className="h-10 w-auto rounded-lg shadow-lg shadow-blue-500/20" />
        </div>
        <div className="w-12" /> {/* Spacer */}
      </header>

      {/* Main Content Area */}
      <main className="px-6 space-y-8 animate-in fade-in duration-500">
        {view === 'home' && (
          <>
            {/* Hero / Welcome */}
            <div className="py-4">
              <h1 className="text-4xl font-extrabold tracking-tight mb-2">
                <span className="text-blue-400">KALY</span> COMPANY
              </h1>
              <p className="text-gray-400 text-sm">{t.welcome}</p>
            </div>

            {/* Search Bar */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                <Search size={20} className="text-gray-500 group-focus-within:text-blue-400 transition-colors" />
              </div>
              <input 
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t.search}
                className="w-full py-4 pl-12 pr-4 bg-white/5 border border-white/10 rounded-3xl focus:outline-none focus:border-blue-500 transition-all text-white placeholder-gray-500 shadow-inner"
              />
            </div>

            {/* Categories Scroll */}
            <div className="flex gap-3 overflow-x-auto scroll-hide pb-2">
              {CATEGORIES.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-6 py-3 rounded-2xl whitespace-nowrap text-sm font-bold transition-all ${
                    activeCategory === cat 
                    ? 'bg-blue-500 text-white shadow-lg shadow-blue-500/30' 
                    : 'bg-white/5 text-gray-400 border border-white/10 hover:bg-white/10'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Product Rotation Simulation (Carousel Style Grid) */}
            <div className="grid grid-cols-2 gap-4 perspective-1000">
              {filteredProducts.map(p => (
                <ProductCard 
                  key={p.id} 
                  product={p} 
                  onView={setSelectedProduct} 
                  onLike={toggleLike}
                  isLiked={user.favorites.includes(p.id)}
                />
              ))}
            </div>
          </>
        )}

        {view === 'categories' && (
           <div className="py-4">
              <h2 className="text-3xl font-bold mb-6">{t.categories}</h2>
              <div className="grid grid-cols-1 gap-4">
                 {CATEGORIES.filter(c => c !== "Tous").map(cat => (
                   <button 
                    key={cat}
                    onClick={() => { setActiveCategory(cat); setView('home'); }}
                    className="p-8 glass rounded-[2rem] flex items-center justify-between group overflow-hidden relative"
                   >
                     <div className="absolute -right-4 top-0 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl group-hover:bg-blue-500/20 transition-colors" />
                     <span className="text-xl font-extrabold tracking-wide">{cat}</span>
                     <ChevronRight className="text-blue-400 group-hover:translate-x-2 transition-transform" />
                   </button>
                 ))}
              </div>
           </div>
        )}

        {view === 'cart' && (
          <div className="py-4">
            <h2 className="text-3xl font-bold mb-8">{t.cart}</h2>
            {cart.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-20 text-gray-500">
                <ShoppingBag size={64} strokeWidth={1} className="mb-4 opacity-20" />
                <p>{t.emptyCart}</p>
              </div>
            ) : (
              <div className="space-y-4">
                {cart.map((item, idx) => (
                  <div key={idx} className="glass p-4 rounded-3xl flex items-center gap-4 animate-in slide-in-from-right-4 duration-300">
                    <img src={item.product.image} className="w-16 h-16 rounded-2xl object-cover" />
                    <div className="flex-1">
                      <p className="font-bold text-white">{item.product.titre}</p>
                      <p className="text-blue-400 text-xs font-semibold">{item.option}</p>
                    </div>
                    <button onClick={() => removeFromCart(idx)} className="p-2 text-red-400 hover:bg-red-400/10 rounded-xl transition-colors">
                      <Minus size={20} />
                    </button>
                  </div>
                ))}
                
                <div className="pt-8 border-t border-white/10">
                   <button 
                    onClick={handleCheckout}
                    className="w-full p-5 bg-blue-500 rounded-3xl flex items-center justify-center gap-3 font-extrabold shadow-2xl shadow-blue-500/40 hover:scale-[1.02] active:scale-95 transition-all"
                   >
                     <MessageCircle size={22} />
                     {t.checkout}
                   </button>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Bottom Nav */}
      <nav className="fixed bottom-6 left-6 right-6 z-50">
        <div className="glass h-20 rounded-[2.5rem] flex items-center justify-around px-4 shadow-2xl border border-white/10">
          <button 
            onClick={() => setView('home')} 
            className={`flex flex-col items-center gap-1 transition-all ${view === 'home' ? 'text-blue-400 scale-110' : 'text-gray-500 hover:text-gray-300'}`}
          >
            <Home size={24} />
            <span className="text-[9px] font-bold">{t.home}</span>
          </button>
          
          <button 
            onClick={() => setView('categories')} 
            className={`flex flex-col items-center gap-1 transition-all ${view === 'categories' ? 'text-blue-400 scale-110' : 'text-gray-500 hover:text-gray-300'}`}
          >
            <Grid size={24} />
            <span className="text-[9px] font-bold">{t.category}</span>
          </button>

          <button 
            onClick={() => setView('cart')} 
            className={`relative flex flex-col items-center gap-1 transition-all ${view === 'cart' ? 'text-blue-400 scale-110' : 'text-gray-500 hover:text-gray-300'}`}
          >
            <ShoppingBag size={24} />
            <span className="text-[9px] font-bold">{t.cart}</span>
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full animate-bounce shadow-lg shadow-red-500/50">
                {cart.length}
              </span>
            )}
          </button>

          <button 
            onClick={() => setLang(l => l === 'fr' ? 'es' : 'fr')} 
            className="flex flex-col items-center gap-1 text-gray-500 hover:text-gray-300 transition-all"
          >
            <Globe size={24} />
            <span className="text-[9px] font-bold">{lang.toUpperCase()}</span>
          </button>
        </div>
      </nav>

      {/* Modals & Overlays */}
      <ProfileDrawer 
        user={user} 
        isOpen={isProfileOpen} 
        onClose={() => setIsProfileOpen(false)} 
        lang={lang}
        onToggleLang={() => setLang(l => l === 'fr' ? 'es' : 'fr')}
      />
      {selectedProduct && (
        <Modal 
          product={selectedProduct} 
          isOpen={!!selectedProduct} 
          onClose={() => setSelectedProduct(null)} 
          onAddToCart={addToCart}
        />
      )}
    </div>
  );
}
