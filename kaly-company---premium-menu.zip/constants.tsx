
import { Product } from './types';

export const PRODUITS: Product[] = [
  {
    id: '1',
    titre: "No Farm 90u",
    category: "Hash",
    image: "https://i.postimg.cc/QMnsXPDQ/IMG-2723.jpg",
    prix: [
      { label: "1,5g", value: "20€" },
      { label: "5g", value: "40€" },
      { label: "10g", value: "70€" }
    ],
    description: "Premium Moroccan quality, 90 micron extraction."
  },
  {
    id: '2',
    titre: "AMNESIA+++",
    category: "Fleur",
    image: "https://i.postimg.cc/mkmPRjdD/IMG-2694.jpg",
    prix: [
      { label: "5g", value: "30€" },
      { label: "10g", value: "50€" }
    ],
    description: "High potency sativa dominant flower."
  },
  {
    id: '3',
    titre: "Écaille de poisson",
    category: "Spécial",
    image: "https://i.postimg.cc/tTyJxww1/IMG-1992.jpg",
    prix: [
      { label: "1g", value: "50€" },
      { label: "5g", value: "220€" },
      { label: "10g", value: "380€" }
    ],
    description: "Ultra pure 0.9% special selection."
  },
  {
    id: '4',
    titre: "Static ROOM USA",
    category: "Extract",
    image: "https://picsum.photos/seed/static/400/400",
    prix: [
      { label: "Disponible", value: "BCN 🇪🇸" }
    ],
    description: "Top shelf USA Static tech."
  },
  {
    id: '5',
    titre: "Cali Plate USA",
    category: "Flower",
    image: "https://picsum.photos/seed/cali/400/400",
    prix: [
      { label: "Disponible", value: "BCN 🇪🇸" }
    ],
    description: "Imported California premium flower plates."
  },
  {
    id: '6',
    titre: "Blueberry Dream",
    category: "Fleur",
    image: "https://picsum.photos/seed/blue/400/400",
    prix: [
      { label: "5g", value: "35€" },
      { label: "10g", value: "60€" }
    ]
  },
  {
    id: '7',
    titre: "Frozen Sift",
    category: "Hash",
    image: "https://picsum.photos/seed/hash/400/400",
    prix: [
      { label: "10g", value: "85€" }
    ]
  }
];

export const CATEGORIES = ["Tous", "Hash", "Fleur", "Extract", "Spécial"];

export const TRANSLATIONS = {
  fr: {
    welcome: "Bienvenue chez KALY COMPANY",
    search: "Rechercher un produit...",
    categories: "Catégories",
    home: "ACCUEIL",
    category: "CATÉGORIE",
    cart: "PANIER",
    lang: "LANGUE",
    viewDetails: "Voir détails",
    commander: "Commander",
    history: "Commandes passées",
    favorites: "Mes favoris",
    coupons: "Bons de réduction",
    orderLimit: "Toutes les 10 commandes, profitez d'un cadeau !",
    nextOrder: "Prochaine étape: 10 commandes",
    emptyCart: "Votre panier est vide",
    total: "Total",
    checkout: "Valider la commande"
  },
  es: {
    welcome: "Bienvenido a KALY COMPANY",
    search: "Buscar un producto...",
    categories: "Categorías",
    home: "INICIO",
    category: "CATEGORÍA",
    cart: "CARRITO",
    lang: "IDIOMA",
    viewDetails: "Ver detalles",
    commander: "Pedir",
    history: "Historial de pedidos",
    favorites: "Mis favoritos",
    coupons: "Cupones de descuento",
    orderLimit: "¡Cada 10 pedidos, recibe un regalo!",
    nextOrder: "Siguiente paso: 10 pedidos",
    emptyCart: "Tu carrito está vacío",
    total: "Total",
    checkout: "Confirmar pedido"
  }
};
